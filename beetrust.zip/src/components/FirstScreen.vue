<template>
  <v-container class="fill-height teste">
    <v-responsive class="align-center text-center fill-height">
      <v-row class="d-flex align-center justify-center">
        <v-col cols="auto">
          <v-card color="grey-lighten-4 teste" theme="dark">
            <div class="d-flex flex-no-wrap justify-space-between">
              <v-avatar :class="xs ? 'ma-0' : 'ma-3'" rounded="0" size="20">
                <v-img
                  src="https://cdn.vuetifyjs.com/images/cards/foster.jpg"
                ></v-img>
              </v-avatar>
              <div>
                <v-card-title class="text-h5"> Supermodel </v-card-title>

                <v-card-subtitle
                  >Ipsum sunt cillum nulla proident velit nisi ut sint commodo
                  consectetur tempor consequat. Fugiat sunt excepteur incididunt
                  ut. Do fugiat laboris esse officia.
                </v-card-subtitle>

                <v-card-actions>
                  <v-btn class="ms-2" variant="outlined"> START RADIO </v-btn>
                </v-card-actions>
              </div>
            </div>
          </v-card>
        </v-col>
      </v-row>
    </v-responsive>
  </v-container>
</template>

<script setup>
import { useDisplay } from "vuetify";

const { xs } = useDisplay();
</script>
