<template>
  <v-app-bar app color="#e9b857" flat d-flex :extended="xs">
    <v-container class="d-flex justify-space-around px-0">
      <LogoElement @drawerChangeStatus="changeDrawer()" />
      <SearchElement :class="xs ? 'hidden-xs' : ''" />
      <WalletElement />
    </v-container>
    <template v-slot:extension v-if="xs">
      <SearchElement class="px-5 mb-5" />
    </template>
  </v-app-bar>
  <v-navigation-drawer app v-model="drawer">
    <v-list
      :class="xs ? 'font-weight-medium pa-0 ma-0' : 'pt-5 font-weight-medium'"
    >
      <v-list-item>.How does it work?</v-list-item>
    </v-list>
    <v-list
      class="new-item-list"
      :class="
        xs
          ? 'font-weight-bold teal-darken-4 pa-0 ma-0'
          : 'pt-5 font-weight-bold teal-darken-4'
      "
    >
      <v-list-item>+ List an Item</v-list-item>
    </v-list>
    <v-list
      class="category-item"
      compact
      :class="xs ? 'font-weight-regular pa-0 ma-0' : 'pt-5 font-weight-regular'"
    >
      <v-list-item class="font-weight-bold">CATEGORIES</v-list-item>
      <v-list-item v-for="category in categories" :key="category">{{
        category
      }}</v-list-item>
    </v-list>
  </v-navigation-drawer>
</template>

<script setup>
import LogoElement from "@/components/topnavbar/LogoElement.vue";
import SearchElement from "@/components/topnavbar/SearchElement.vue";
import WalletElement from "@/components/topnavbar/WalletElement.vue";
import { ref } from "vue";
import { useDisplay } from "vuetify";

const { xs } = useDisplay();

const drawer = ref();
const categories = ref([
  ".service & solution",
  ".travel & accommodation",
  ".real state & furniture",
  ".furniture & appliances",
  ".fashion & beauty",
  ".eletronic & media",
  ".food & personal care",
  ".toys, diy & hobbies",
  ".games & digital contents",
]);

function changeDrawer() {
  drawer.value = !drawer.value;
}
</script>

<style scoped lang="scss">
.category-item,
.new-item-list {
  cursor: pointer;
}
</style>
